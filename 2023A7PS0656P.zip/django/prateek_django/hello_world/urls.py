"""hello_world URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from hello_world.core import views as core_views

urlpatterns = [
    path("", core_views.index),
    path("register/",core_views.register),
    path("profile/",core_views.get_profile),
    path("login/", core_views.sign_in),
    path("logout/",core_views.logout_request),
    path("add_order/",core_views.add_order),
    path("admin/", admin.site.urls),
    path("delete/<int:id>", core_views.delete_order),
    path("update/<int:id>", core_views.update_order),
    path("about/",core_views.about),
    path("__reload__/", include("django_browser_reload.urls")),
]
