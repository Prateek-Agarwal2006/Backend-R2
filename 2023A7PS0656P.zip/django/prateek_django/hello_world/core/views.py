import json
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import LoginForm, OrderForm,UpdateForm
from django.contrib import messages
from django.contrib.auth import login, authenticate,logout
from .models import Order

def index(request):
    context = {
        "title": "Django example",
    }
    return render(request, "index.html", context)

def register(request):
    if request.method != 'POST':
        form = UserCreationForm()
    else:
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/login')

    context = {'form': form}
    return render(request, 'register.html', context)

def sign_in(request):
    if request.method == 'GET':
        form = LoginForm()
        return render(request,'login.html', {'form': form})
    
    elif request.method == 'POST':


        form = LoginForm(request.POST)
        
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
           
            user = authenticate(request,username=username,password=password)
           
            if user:
                login(request, user)
                return redirect('/profile')
        
            messages.error(request,'Invalid username or password')
            return render(request,'login.html',{'form': form})


def get_profile(request):
    username = request.user

    if username.is_anonymous:
        return redirect("/login")
    
    orders = Order.objects.filter(user=request.user)

    
    
    
    return render(request, "profile.html", {'username': username, 'orders': orders})
 

def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.") 
	return redirect("/login")

def about(request):
    return render(request, 'about.html')

def add_order(request):
    if request.user.is_anonymous:
        return redirect("/login")

    if request.method == 'GET':
        form = OrderForm()
        return render(request,'add_order.html', {'form': form})
    
    elif request.method == 'POST':
        form = UpdateForm(request.POST)
        
        if form.is_valid():
            order = form.save(commit=False)
            order.user = request.user
            order.save()

            return redirect("/profile")




def delete_order(request,id):
    order = Order.objects.filter(id=id)
    order.delete()
    return redirect('/profile')


def update_order(request, id):
    if request.method == 'GET':
        form = UpdateForm()
        return render(request,'update_order.html', {'form': form})
    
    elif request.method == 'POST':
        form = UpdateForm(request.POST)
        
        if form.is_valid():
            name = form.cleaned_data["name"]
            product_no = form.cleaned_data["product_no"]
            price = form.cleaned_data["price"]

            Order.objects.filter(id=id).update(name=name, product_no=product_no, price=price)

            return redirect("/profile")

















