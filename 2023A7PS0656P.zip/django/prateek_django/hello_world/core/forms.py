from django import forms
from django.forms import ModelForm
from django.contrib.auth.models import User
from .models import Order


# Create your forms here.
class LoginForm(forms.Form):
    username = forms.CharField(max_length=65)
    password = forms.CharField(max_length=65, widget=forms.PasswordInput)

class OrderForm(ModelForm):
    class Meta:
        model = Order
        exclude = ('user',)

class UpdateForm(ModelForm):
    class Meta:
        model=Order
        exclude=('user',)        


        

